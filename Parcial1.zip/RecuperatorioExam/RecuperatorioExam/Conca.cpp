#include "StdAfx.h"
#include "Conca.h"


Conca::Conca(void)
{
	vec[N]=0;
	tamano=0;
}

int Conca::Get_vec(int pos)
{
	return vec[pos];
}
void Conca::Set_vec(int pos, int e)
{
	vec[pos]=e;
}
int Conca::Get_tam()
{
	return tamano;
}
void Conca::Set_tam(int tam)
{
	tamano=tam;
}
Conca Conca::concatenar(Conca x, Conca y)
{Conca z; int aux, aux2;
z.tamano=x.tamano+y.tamano;
aux=x.tamano;
aux2=y.tamano;
for(int i=0;i<aux;i++)
{z.vec[i]=x.vec[i];}
for(int i=aux;i<z.tamano;i++)
{z.vec[i]=y.vec[i-aux];}
return z;
}