#pragma once
#include "Conca.h"

namespace RecuperatorioExam {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace std;

	Conca a;
	Conca b;
	Conca c;
	int pos=0, poss=0;

	/// <summary>
	/// Summary for Form1
	/// </summary>
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Button^  btncon;
	protected: 
	private: System::Windows::Forms::TextBox^  txtval2;
	private: System::Windows::Forms::TextBox^  txttam2;
	private: System::Windows::Forms::Label^  label4;
	private: System::Windows::Forms::Label^  label3;
	private: System::Windows::Forms::Button^  btnval2;
	private: System::Windows::Forms::Button^  btndef2;
	private: System::Windows::Forms::Button^  btnin1;
	private: System::Windows::Forms::Button^  btndef1;
	private: System::Windows::Forms::DataGridView^  grid3;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Column3;
	private: System::Windows::Forms::DataGridView^  grid2;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Column2;
	private: System::Windows::Forms::DataGridView^  grid1;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Column1;
	private: System::Windows::Forms::TextBox^  txtval1;
	private: System::Windows::Forms::TextBox^  txttam1;
	private: System::Windows::Forms::Label^  label2;
	private: System::Windows::Forms::Label^  label1;

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->btncon = (gcnew System::Windows::Forms::Button());
			this->txtval2 = (gcnew System::Windows::Forms::TextBox());
			this->txttam2 = (gcnew System::Windows::Forms::TextBox());
			this->label4 = (gcnew System::Windows::Forms::Label());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->btnval2 = (gcnew System::Windows::Forms::Button());
			this->btndef2 = (gcnew System::Windows::Forms::Button());
			this->btnin1 = (gcnew System::Windows::Forms::Button());
			this->btndef1 = (gcnew System::Windows::Forms::Button());
			this->grid3 = (gcnew System::Windows::Forms::DataGridView());
			this->Column3 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->grid2 = (gcnew System::Windows::Forms::DataGridView());
			this->Column2 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->grid1 = (gcnew System::Windows::Forms::DataGridView());
			this->Column1 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->txtval1 = (gcnew System::Windows::Forms::TextBox());
			this->txttam1 = (gcnew System::Windows::Forms::TextBox());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->label1 = (gcnew System::Windows::Forms::Label());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->grid3))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->grid2))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->grid1))->BeginInit();
			this->SuspendLayout();
			// 
			// btncon
			// 
			this->btncon->Location = System::Drawing::Point(567, 52);
			this->btncon->Name = L"btncon";
			this->btncon->Size = System::Drawing::Size(75, 23);
			this->btncon->TabIndex = 31;
			this->btncon->Text = L"Concatenar";
			this->btncon->UseVisualStyleBackColor = true;
			this->btncon->Click += gcnew System::EventHandler(this, &Form1::btncon_Click);
			// 
			// txtval2
			// 
			this->txtval2->Location = System::Drawing::Point(326, 69);
			this->txtval2->Name = L"txtval2";
			this->txtval2->Size = System::Drawing::Size(57, 20);
			this->txtval2->TabIndex = 30;
			// 
			// txttam2
			// 
			this->txttam2->Location = System::Drawing::Point(326, 31);
			this->txttam2->Name = L"txttam2";
			this->txttam2->Size = System::Drawing::Size(57, 20);
			this->txttam2->TabIndex = 29;
			// 
			// label4
			// 
			this->label4->AutoSize = true;
			this->label4->Location = System::Drawing::Point(284, 69);
			this->label4->Name = L"label4";
			this->label4->Size = System::Drawing::Size(45, 13);
			this->label4->TabIndex = 28;
			this->label4->Text = L"Valores:";
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Location = System::Drawing::Point(284, 31);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(49, 13);
			this->label3->TabIndex = 27;
			this->label3->Text = L"Tama�o:";
			// 
			// btnval2
			// 
			this->btnval2->Location = System::Drawing::Point(390, 66);
			this->btnval2->Name = L"btnval2";
			this->btnval2->Size = System::Drawing::Size(75, 23);
			this->btnval2->TabIndex = 26;
			this->btnval2->Text = L"Ingresar";
			this->btnval2->UseVisualStyleBackColor = true;
			this->btnval2->Click += gcnew System::EventHandler(this, &Form1::btnval2_Click);
			// 
			// btndef2
			// 
			this->btndef2->Location = System::Drawing::Point(390, 31);
			this->btndef2->Name = L"btndef2";
			this->btndef2->Size = System::Drawing::Size(75, 23);
			this->btndef2->TabIndex = 25;
			this->btndef2->Text = L"Definir";
			this->btndef2->UseVisualStyleBackColor = true;
			this->btndef2->Click += gcnew System::EventHandler(this, &Form1::btndef2_Click);
			// 
			// btnin1
			// 
			this->btnin1->Location = System::Drawing::Point(183, 52);
			this->btnin1->Name = L"btnin1";
			this->btnin1->Size = System::Drawing::Size(75, 23);
			this->btnin1->TabIndex = 24;
			this->btnin1->Text = L"Ingresar";
			this->btnin1->UseVisualStyleBackColor = true;
			this->btnin1->Click += gcnew System::EventHandler(this, &Form1::btnin1_Click);
			// 
			// btndef1
			// 
			this->btndef1->Location = System::Drawing::Point(183, 28);
			this->btndef1->Name = L"btndef1";
			this->btndef1->Size = System::Drawing::Size(75, 23);
			this->btndef1->TabIndex = 23;
			this->btndef1->Text = L"Definir";
			this->btndef1->UseVisualStyleBackColor = true;
			this->btndef1->Click += gcnew System::EventHandler(this, &Form1::btndef1_Click);
			// 
			// grid3
			// 
			this->grid3->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->grid3->Columns->AddRange(gcnew cli::array< System::Windows::Forms::DataGridViewColumn^  >(1) {this->Column3});
			this->grid3->Location = System::Drawing::Point(506, 99);
			this->grid3->Name = L"grid3";
			this->grid3->Size = System::Drawing::Size(161, 150);
			this->grid3->TabIndex = 22;
			// 
			// Column3
			// 
			this->Column3->HeaderText = L"Concatenado";
			this->Column3->Name = L"Column3";
			// 
			// grid2
			// 
			this->grid2->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->grid2->Columns->AddRange(gcnew cli::array< System::Windows::Forms::DataGridViewColumn^  >(1) {this->Column2});
			this->grid2->Location = System::Drawing::Point(284, 131);
			this->grid2->Name = L"grid2";
			this->grid2->Size = System::Drawing::Size(181, 150);
			this->grid2->TabIndex = 21;
			// 
			// Column2
			// 
			this->Column2->HeaderText = L"Valores";
			this->Column2->Name = L"Column2";
			// 
			// grid1
			// 
			this->grid1->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->grid1->Columns->AddRange(gcnew cli::array< System::Windows::Forms::DataGridViewColumn^  >(1) {this->Column1});
			this->grid1->Location = System::Drawing::Point(55, 131);
			this->grid1->Name = L"grid1";
			this->grid1->Size = System::Drawing::Size(174, 150);
			this->grid1->TabIndex = 20;
			// 
			// Column1
			// 
			this->Column1->HeaderText = L"Valores";
			this->Column1->Name = L"Column1";
			// 
			// txtval1
			// 
			this->txtval1->Location = System::Drawing::Point(113, 63);
			this->txtval1->Name = L"txtval1";
			this->txtval1->Size = System::Drawing::Size(53, 20);
			this->txtval1->TabIndex = 19;
			// 
			// txttam1
			// 
			this->txttam1->Location = System::Drawing::Point(113, 31);
			this->txttam1->Name = L"txttam1";
			this->txttam1->Size = System::Drawing::Size(53, 20);
			this->txttam1->TabIndex = 18;
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Location = System::Drawing::Point(52, 63);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(45, 13);
			this->label2->TabIndex = 17;
			this->label2->Text = L"Valores:";
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Location = System::Drawing::Point(49, 31);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(49, 13);
			this->label1->TabIndex = 16;
			this->label1->Text = L"Tama�o:";
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(717, 309);
			this->Controls->Add(this->btncon);
			this->Controls->Add(this->txtval2);
			this->Controls->Add(this->txttam2);
			this->Controls->Add(this->label4);
			this->Controls->Add(this->label3);
			this->Controls->Add(this->btnval2);
			this->Controls->Add(this->btndef2);
			this->Controls->Add(this->btnin1);
			this->Controls->Add(this->btndef1);
			this->Controls->Add(this->grid3);
			this->Controls->Add(this->grid2);
			this->Controls->Add(this->grid1);
			this->Controls->Add(this->txtval1);
			this->Controls->Add(this->txttam1);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->label1);
			this->Name = L"Form1";
			this->Text = L"Form1";
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->grid3))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->grid2))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->grid1))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void btndef1_Click(System::Object^  sender, System::EventArgs^  e) {
				 int tam;
				 tam=System::Convert::ToInt32(txttam1->Text);
				 a.Set_tam(tam);
				 grid1->RowCount=tam;
			 }
private: System::Void btnin1_Click(System::Object^  sender, System::EventArgs^  e) {
			 int num;
			 num=System::Convert::ToInt32(txtval1->Text);
			 a.Set_vec(pos,num);
			 grid1->Rows[pos]->Cells[0]->Value=num;
			 pos++;
		 }
private: System::Void btndef2_Click(System::Object^  sender, System::EventArgs^  e) {
			int tam;
				 tam=System::Convert::ToInt32(txttam2->Text);
				 b.Set_tam(tam);
				 grid2->RowCount=tam;
		 }
private: System::Void btnval2_Click(System::Object^  sender, System::EventArgs^  e) {
			 int num;
			 num=System::Convert::ToInt32(txtval2->Text);
			 b.Set_vec(poss,num);
			 grid2->Rows[poss]->Cells[0]->Value=num;
			 poss++;
		 }
private: System::Void btncon_Click(System::Object^  sender, System::EventArgs^  e) {
			 c=c.concatenar(a,b);
			 grid3->RowCount=c.Get_tam();
			 for(int i=0; i<c.Get_tam(); i++)
			 {
				 grid3->Rows[i]->Cells[0]->Value=c.Get_vec(i);
			 }
		 }
};
}

