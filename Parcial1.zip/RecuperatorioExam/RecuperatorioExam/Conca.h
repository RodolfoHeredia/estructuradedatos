#pragma once
#define N 50

class Conca
{
private:
	int vec[N];
	int tamano;

public:
	Conca(void);
	int Get_vec(int pos);
	void Set_vec(int pos, int e);
	int Get_tam();
	void Set_tam(int tam);
	Conca concatenar(Conca x, Conca y);
};

