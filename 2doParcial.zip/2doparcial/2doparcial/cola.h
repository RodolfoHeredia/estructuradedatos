#pragma once
#define N 50

class cola
{
private:
	int frente;
	int final;
	int C[N];
	int tamano;
public:
	cola(void);
	void encolar(int x);
	int desencolar();
	bool lleno();
	bool vacio();
	int eliminar(int x);
	void set_tam(int x);
	int get_tam();
};

