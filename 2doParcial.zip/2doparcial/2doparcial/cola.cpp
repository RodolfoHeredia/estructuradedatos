#include "StdAfx.h"
#include "cola.h"


cola::cola(void)
{
	frente=0;
	final=-1;
	C[N]=0;
	tamano=0;
}
void cola::encolar(int x)
{
	C[++final]=x;
}
int cola::desencolar()
{
	int aux;
	aux=C[frente++];
	return aux;
}
bool cola::lleno()
{
	if(final==N-1)
		return true;
	else
		return false;
}
bool cola::vacio()
{
	if(final==-1)
		return true;
	else
		return false;
}
int cola::eliminar(int x)
{
	 int aux;
			 for(int i=0; i<x;i++)
			 {
				 if(C[i]!=C[i+1])
				 {aux=C[i];
				 }
			 }
			 return aux;
}
void cola::set_tam(int x)
{
	tamano=x;
}
int cola::get_tam()
{
	return tamano;
}