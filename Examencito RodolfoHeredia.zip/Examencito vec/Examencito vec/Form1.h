#pragma once
#include <iostream>
#include "Vectoresss.h"

namespace Examencitovec {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace std;
	

	Vectoresss a;
	int pos=0;
	/// <summary>
	/// Summary for Form1
	/// </summary>
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Label^  label1;
	protected: 
	private: System::Windows::Forms::Label^  label2;
	private: System::Windows::Forms::TextBox^  txttam;
	private: System::Windows::Forms::TextBox^  txtval;
	private: System::Windows::Forms::DataGridView^  grilla;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Column1;
	private: System::Windows::Forms::Button^  btndef;
	private: System::Windows::Forms::Button^  btnin;
	private: System::Windows::Forms::Button^  btncal;

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->txttam = (gcnew System::Windows::Forms::TextBox());
			this->txtval = (gcnew System::Windows::Forms::TextBox());
			this->grilla = (gcnew System::Windows::Forms::DataGridView());
			this->Column1 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->btndef = (gcnew System::Windows::Forms::Button());
			this->btnin = (gcnew System::Windows::Forms::Button());
			this->btncal = (gcnew System::Windows::Forms::Button());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->grilla))->BeginInit();
			this->SuspendLayout();
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Location = System::Drawing::Point(29, 33);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(49, 13);
			this->label1->TabIndex = 0;
			this->label1->Text = L"Tama�o:";
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Location = System::Drawing::Point(32, 74);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(37, 13);
			this->label2->TabIndex = 1;
			this->label2->Text = L"Valor: ";
			// 
			// txttam
			// 
			this->txttam->Location = System::Drawing::Point(96, 33);
			this->txttam->Name = L"txttam";
			this->txttam->Size = System::Drawing::Size(100, 20);
			this->txttam->TabIndex = 2;
			// 
			// txtval
			// 
			this->txtval->Location = System::Drawing::Point(96, 66);
			this->txtval->Name = L"txtval";
			this->txtval->Size = System::Drawing::Size(100, 20);
			this->txtval->TabIndex = 3;
			// 
			// grilla
			// 
			this->grilla->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->grilla->Columns->AddRange(gcnew cli::array< System::Windows::Forms::DataGridViewColumn^  >(1) {this->Column1});
			this->grilla->Location = System::Drawing::Point(12, 100);
			this->grilla->Name = L"grilla";
			this->grilla->Size = System::Drawing::Size(240, 150);
			this->grilla->TabIndex = 4;
			// 
			// Column1
			// 
			this->Column1->HeaderText = L"Vector 1";
			this->Column1->Name = L"Column1";
			// 
			// btndef
			// 
			this->btndef->Location = System::Drawing::Point(202, 28);
			this->btndef->Name = L"btndef";
			this->btndef->Size = System::Drawing::Size(75, 23);
			this->btndef->TabIndex = 5;
			this->btndef->Text = L"Definir";
			this->btndef->UseVisualStyleBackColor = true;
			this->btndef->Click += gcnew System::EventHandler(this, &Form1::btndef_Click);
			// 
			// btnin
			// 
			this->btnin->Location = System::Drawing::Point(202, 63);
			this->btnin->Name = L"btnin";
			this->btnin->Size = System::Drawing::Size(75, 23);
			this->btnin->TabIndex = 6;
			this->btnin->Text = L"Ingresar";
			this->btnin->UseVisualStyleBackColor = true;
			this->btnin->Click += gcnew System::EventHandler(this, &Form1::btnin_Click);
			// 
			// btncal
			// 
			this->btncal->Location = System::Drawing::Point(306, 54);
			this->btncal->Name = L"btncal";
			this->btncal->Size = System::Drawing::Size(75, 23);
			this->btncal->TabIndex = 7;
			this->btncal->Text = L"Calcular";
			this->btncal->UseVisualStyleBackColor = true;
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(559, 302);
			this->Controls->Add(this->btncal);
			this->Controls->Add(this->btnin);
			this->Controls->Add(this->btndef);
			this->Controls->Add(this->grilla);
			this->Controls->Add(this->txtval);
			this->Controls->Add(this->txttam);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->label1);
			this->Name = L"Form1";
			this->Text = L"Form1";
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->grilla))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void btndef_Click(System::Object^  sender, System::EventArgs^  e) {
				 int tam;
				 a.Set_tamano(tam);
				 tam=Convert::ToInt32(txttam->Text);
				 grilla->RowCount=tam;
			 }

	private: System::Void btncal_Click(System::Object^  sender, System::EventArgs^  e) {
				 int tam;
				 grilla->Rows[0]->Cell[0]=a.calcular(int vec[], tam);
				 pos++;
				
			 }


