#pragma once
#define N 100

class Vectoresss
{
private:
		int vec[N];
		int tamano;
public:
	Vectoresss(void);
	int Get_tamano();
	void Set_tamano(int tam1);
	int Get_vector(int pos1);                                                                   
	void Set_vector(int pos1,int elem1);
	int calcular(int n);        
};

