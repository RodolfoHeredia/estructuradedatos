#include "StdAfx.h"
#include "Vectoresss.h"
#include <iostream>

using namespace std;

Vectoresss::Vectoresss(void)
{
	vec[N]=0;
	tamano=0;
}

int Vectoresss::Get_tamano()
{return tamano;}
	
void Vectoresss::Set_tamano(int tam)
{tamano=tam;}

int Vectoresss::Get_vector(int pos)
{return vec[pos];}

void Vectoresss::Set_vector(int pos, int elem)
{vec[pos]=elem;}

int calcular (int n)
{int i;
for(i=0;i<n;i++)
{if(i/3==0)
{return i;}
}
}