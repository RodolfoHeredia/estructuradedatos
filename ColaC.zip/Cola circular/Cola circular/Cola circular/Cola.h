#pragma once
#define N 40
class Cola
{
private:
	int front;
	int rear;
	int V[N];
public:
	Cola(void);

};

