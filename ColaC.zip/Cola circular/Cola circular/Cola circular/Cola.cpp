#include "StdAfx.h"
#include "Cola.h"


Cola::Cola(void)
{
}
