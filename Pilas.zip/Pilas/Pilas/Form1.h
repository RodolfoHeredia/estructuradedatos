#pragma once
#include "Pila.h"
namespace Pilas {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	Pila A;
	int tam=0;
	/// <summary>
	/// Summary for Form1
	/// </summary>
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Label^  label1;
	protected: 
	private: System::Windows::Forms::TextBox^  txtTamano;
	private: System::Windows::Forms::Button^  btnDefinir;
	private: System::Windows::Forms::Button^  btnPush;
	private: System::Windows::Forms::TextBox^  txtPush;
	private: System::Windows::Forms::Label^  label2;
	private: System::Windows::Forms::Button^  btnPop;
	private: System::Windows::Forms::TextBox^  txtPop;
	private: System::Windows::Forms::Label^  label3;
	private: System::Windows::Forms::DataGridView^  Grid1;

	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Column1;

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->txtTamano = (gcnew System::Windows::Forms::TextBox());
			this->btnDefinir = (gcnew System::Windows::Forms::Button());
			this->btnPush = (gcnew System::Windows::Forms::Button());
			this->txtPush = (gcnew System::Windows::Forms::TextBox());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->btnPop = (gcnew System::Windows::Forms::Button());
			this->txtPop = (gcnew System::Windows::Forms::TextBox());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->Grid1 = (gcnew System::Windows::Forms::DataGridView());
			this->Column1 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->Grid1))->BeginInit();
			this->SuspendLayout();
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Location = System::Drawing::Point(18, 29);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(46, 13);
			this->label1->TabIndex = 0;
			this->label1->Text = L"Tamano";
			// 
			// txtTamano
			// 
			this->txtTamano->Location = System::Drawing::Point(70, 26);
			this->txtTamano->Name = L"txtTamano";
			this->txtTamano->Size = System::Drawing::Size(100, 20);
			this->txtTamano->TabIndex = 1;
			// 
			// btnDefinir
			// 
			this->btnDefinir->Location = System::Drawing::Point(194, 18);
			this->btnDefinir->Name = L"btnDefinir";
			this->btnDefinir->Size = System::Drawing::Size(78, 34);
			this->btnDefinir->TabIndex = 2;
			this->btnDefinir->Text = L"Definir";
			this->btnDefinir->UseVisualStyleBackColor = true;
			this->btnDefinir->Click += gcnew System::EventHandler(this, &Form1::btnDefinir_Click);
			// 
			// btnPush
			// 
			this->btnPush->Location = System::Drawing::Point(194, 63);
			this->btnPush->Name = L"btnPush";
			this->btnPush->Size = System::Drawing::Size(78, 34);
			this->btnPush->TabIndex = 5;
			this->btnPush->Text = L"Push";
			this->btnPush->UseVisualStyleBackColor = true;
			this->btnPush->Click += gcnew System::EventHandler(this, &Form1::btnPush_Click);
			// 
			// txtPush
			// 
			this->txtPush->Location = System::Drawing::Point(70, 71);
			this->txtPush->Name = L"txtPush";
			this->txtPush->Size = System::Drawing::Size(100, 20);
			this->txtPush->TabIndex = 4;
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Location = System::Drawing::Point(18, 74);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(44, 13);
			this->label2->TabIndex = 3;
			this->label2->Text = L"Numero";
			// 
			// btnPop
			// 
			this->btnPop->Location = System::Drawing::Point(194, 106);
			this->btnPop->Name = L"btnPop";
			this->btnPop->Size = System::Drawing::Size(78, 34);
			this->btnPop->TabIndex = 8;
			this->btnPop->Text = L"Pop";
			this->btnPop->UseVisualStyleBackColor = true;
			this->btnPop->Click += gcnew System::EventHandler(this, &Form1::btnPop_Click);
			// 
			// txtPop
			// 
			this->txtPop->Location = System::Drawing::Point(70, 114);
			this->txtPop->Name = L"txtPop";
			this->txtPop->Size = System::Drawing::Size(100, 20);
			this->txtPop->TabIndex = 7;
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Location = System::Drawing::Point(18, 117);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(44, 13);
			this->label3->TabIndex = 6;
			this->label3->Text = L"Numero";
			// 
			// Grid1
			// 
			this->Grid1->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->Grid1->Columns->AddRange(gcnew cli::array< System::Windows::Forms::DataGridViewColumn^  >(1) {this->Column1});
			this->Grid1->Location = System::Drawing::Point(23, 190);
			this->Grid1->Name = L"Grid1";
			this->Grid1->Size = System::Drawing::Size(248, 158);
			this->Grid1->TabIndex = 9;
			// 
			// Column1
			// 
			this->Column1->HeaderText = L"Numero";
			this->Column1->Name = L"Column1";
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(305, 389);
			this->Controls->Add(this->Grid1);
			this->Controls->Add(this->btnPop);
			this->Controls->Add(this->txtPop);
			this->Controls->Add(this->label3);
			this->Controls->Add(this->btnPush);
			this->Controls->Add(this->txtPush);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->btnDefinir);
			this->Controls->Add(this->txtTamano);
			this->Controls->Add(this->label1);
			this->Name = L"Form1";
			this->Text = L"Form1";
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->Grid1))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void btnDefinir_Click(System::Object^  sender, System::EventArgs^  e) {
				 int tam;
				 tam=Convert::ToInt32(txtTamano->Text);
				 A.Set_Tamano(tam);
				 Grid1->RowCount=tam;
			 }
private: System::Void btnPush_Click(System::Object^  sender, System::EventArgs^  e) {
			 int x;
			 x=Convert::ToInt32(txtPush->Text);
		     if (A.Full())
				 MessageBox::Show("Pila llena");
			 else 
			 {A.Push(x);
			 Grid1->Rows[tam]->Cells[0]->Value=x;
			 tam++;}
		 }
private: System::Void btnPop_Click(System::Object^  sender, System::EventArgs^  e) {
			 int x;
		     if (A.Empty())
				 MessageBox::Show("Pila vacia");
			 else 
			 {x=A.Pop();
			  txtPop->Text=Convert::ToString(x);
			 }
		 }
};
}

// #(){}[]<>\|/"+

