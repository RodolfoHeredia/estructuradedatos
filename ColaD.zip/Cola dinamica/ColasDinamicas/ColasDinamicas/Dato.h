#pragma once
#include <string>
using namespace std;
class Dato
{
public:
	Dato(void);
	~Dato(void);
	double Codigo; 
    string Nombre; 
    string Carrera;
};

