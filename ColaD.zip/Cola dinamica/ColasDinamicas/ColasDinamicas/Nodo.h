#pragma once
#include "Dato.h"
class Nodo
{
public:
	Nodo(void);
	~Nodo(void);
};

