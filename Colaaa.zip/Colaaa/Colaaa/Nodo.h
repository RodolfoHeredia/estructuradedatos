#pragma once
class Nodo
{
protected:
	int numero;
	double carnet;
public:
	Nodo();
	void insertar(int x, double y);
};

