#include "StdAfx.h"
#include "Cola.h"


Cola::Cola(void)
{
	frente=0;
	final=-1;
}
void Cola::encolar(Nodo x)
{
	V[++final]=x;

}
Nodo Cola::desencolar(
{
	Nodo aux=V[frente++];
	return aux;
}
bool Cola::lleno()
{
	if (fial == N-1)
		return true;
	else
		return false;
}
bool Cola::vacio()
{
	if (final==-1)
	    return true;
	else
		return false;
}
