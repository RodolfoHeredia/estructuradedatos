#include "StdAfx.h"
#include "Nodo.h"


Nodo::Nodo(void)
{}
void Nodo::insertar(int x, double y)
{
	numero=x;
	carnet=y;

}
