#pragma once
#include "Nodo.h"
#define N 25
class Cola: public Nodo
{
private:
	int frente;
	int final;
	Nodo V[N];
public:
	Cola(void);
	void encolar(Nodo x);
	Nodo desencolar();
	bool lleno();
	bool vacio();

};


