#include "StdAfx.h"
#include "Voleibol.h"
#include "Partido.h"


Voleibol::Voleibol(void)
{}
void Voleibol::Set_puntos1(int x)
{puntos1=x;}
void Voleibol::Set_puntos2(int y)
{puntos2=y;}
int Voleibol::Get_puntos1()
{return puntos1;}
int Voleibol::Get_puntos2()
{return puntos2;}
