#pragma once
#include "Partido.h"
class Futbol:public Partido
{
private:
	int goles1;
	int goles2;
public:
	Futbol(void);
	void Set_goles1(int goles1);
	void Set_goles2(int goles2);
	int Get_goles1();
	int Get_goles2();
};

