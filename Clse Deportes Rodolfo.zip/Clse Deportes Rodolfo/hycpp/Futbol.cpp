#include "StdAfx.h"
#include "Futbol.h"
#include "Partido.h"

Futbol::Futbol(void){}
	void Futbol::Set_goles1(int x)
	{goles1=x;}
	void Futbol::Set_goles2(int y)
	{goles2=y;}
	int Futbol::Get_goles1()
	{return goles1;}
	int Futbol::Get_goles2()
	{return goles2;}
