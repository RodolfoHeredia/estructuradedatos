#include "StdAfx.h"
#include "Partido.h"


Partido::Partido(void){}
void Partido::Set_jugadores(int jug)
{jugadores=jug;}
int Partido::Get_jugares()
{return jugadores;}
int Calcular (int x, int y)
{
if (x>y)
return 1;
else
return 2;
}