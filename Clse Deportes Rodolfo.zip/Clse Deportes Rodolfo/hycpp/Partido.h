#pragma once
#include <iostream>

using namespace std;

class Partido
{
protected:
	int jugadores;

public:
	Partido(void);
	void Set_jugadores(int jug);
	int Get_jugares();
	int Calcular(int x, int y);
	
};

