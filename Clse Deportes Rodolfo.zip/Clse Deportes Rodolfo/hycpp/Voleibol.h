#pragma once
#include "Partido.h"
class Voleibol:public Partido

{
private:
	int puntos1;
	int puntos2;
public:
	Voleibol(void);
	void Set_puntos1(int puntos1);
	void Set_puntos2(int puntos2);
	int Get_puntos1();
	int Get_puntos2();
};

