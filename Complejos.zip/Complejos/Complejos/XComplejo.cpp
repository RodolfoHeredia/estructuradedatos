#include "StdAfx.h"
#include "XComplejo.h"


XComplejo::XComplejo(void)
{
}
XComplejo::XComplejo(double r, double i)
{
real=r;
imag=i;
}
void XComplejo::Set_real(double r)
{real=r;}
void XComplejo::Set_imag(double i)
{imag=i;}
double XComplejo::Get_real()
{return real;}
double XComplejo::Get_imag()
{return imag;}
void XComplejo::suma(XComplejo a, XComplejo b)
{
real=a.real+b.real;
imag=a.imag+b.imag;
}