#pragma once
ref class XComplejo
{

private:
	double real, imag;

public:
	XComplejo(void);
XComplejo(double r, double i);
	void Set_real(double r);
	void Set_imag(double i);
	double Get_real();
	double Get_imag();
	void suma(XComplejo a, XComplejo b);
};

