#pragma once
ref class CComplejos
{
private:
	double real, imag;

public:
	CComplejos(void);
	void Set_real(double r);
	void Set_imag(double i);
	double Get_real();
	double Get_imag();
	void suma(CComplejos a, CComplejos b);
};

